import warnings
from typing import Tuple

import torch
import torch.nn as nn
from timm.data.mixup import Mixup
from torch.utils.data import DataLoader

from ..models import get_model_target_size


class MixupMixin:
    """Mixin class that adds LR scheduler functionality to the trainer class.

    The SchedulerMixin supports PyTorch and timm schedulers.

    Parameters
    ----------
    model
        Pytorch neural network.
        MixupMixin uses it to get number of classes.
    trainloader
        Pytorch dataloader with training data.
        MixupMixin uses it to get number of classes.
    mixup
        Mixup alpha value, mixup is active if > 0.
    cutmix
        Cutmix alpha value, cutmix is active if > 0.
    mixup_prob
        Probability of applying mixup or cutmix per batch.
    """

    def __init__(
        self,
        model: nn.Module,
        trainloader: DataLoader = None,
        *args,
        mixup: float = 0.0,
        cutmix: float = 0.0,
        mixup_prob: float = 1.0,
        **kwargs,
    ):
        # set default values (in case of script sets them as None)
        mixup = mixup or 0.0
        cutmix = cutmix or 0.0
        mixup_prob = mixup_prob or 1.0

        # create mixup class
        if mixup > 0.0 or cutmix > 0.0:
            # get number of classes from model and trainset for Mixup method
            num_classes = get_model_target_size(model)
            if num_classes is not None:
                self.mixup_fn = Mixup(
                    mixup_alpha=mixup,
                    cutmix_alpha=cutmix,
                    cutmix_minmax=None,
                    prob=mixup_prob,
                    switch_prob=0.5,
                    mode="batch",
                    correct_lam=True,
                    label_smoothing=0.1,
                    num_classes=num_classes,
                )
            else:
                warnings.warn("Could not identify number of classes from model. Not using MixUp.")
        else:
            self.mixup_fn = None

        # call parent class to initialize trainer
        super().__init__(*args, model=model, trainloader=trainloader, **kwargs)

    def apply_mixup(
        self, imgs: torch.Tensor, targs: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Apply mixup or cutmix method if arguments `mixup` or `cutmix` were used in Trainer."""
        if self.mixup_fn is not None:
            imgs, targs = self.mixup_fn(imgs, targs)
        return imgs, targs
